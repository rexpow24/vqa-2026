# Map câu trả lời nhóm V vào codebook bằng ChatGPT web

Cần: Python 3.10 trở lên và pandas (`pip install pandas`).

## Các bước

1. Giải nén, mở terminal ở thư mục vừa giải nén.
2. Chạy:

   ```
   python scripts/codebook_map.py chat --group V
   ```

3. Mỗi lô (11 lô, mỗi lô 25 câu):
   - Script in prompt và copy sẵn vào clipboard (Windows).
   - Mở một cuộc trò chuyện MỚI trên ChatGPT, Ctrl+V, gửi.
   - Copy câu trả lời của ChatGPT, dán vào terminal.
     Script tự nhận khi JSON đủ; nếu không, gõ `END` rồi Enter.
   - Hợp lệ thì script lưu và chuyển sang lô sau.
     Có câu lỗi thì chọn: Enter rồi dán lại, `save` để vẫn lưu, `skip` bỏ lô, `quit` dừng.
4. Muốn nghỉ thì gõ `quit`; chạy lại lệnh ở bước 2 để làm tiếp từ lô còn thiếu.
5. Xong hết, gửi lại file `csvs/p1-V/outputs.jsonl`.
   Muốn xem độ phủ thì chạy `python scripts/codebook_map.py report --group V` (ra `csvs/p1-V/coverage_V.txt`).

Không sửa `units.csv`, `requests.jsonl` và `p1-prompt.md`: script dùng chúng để kiểm câu trả lời.
